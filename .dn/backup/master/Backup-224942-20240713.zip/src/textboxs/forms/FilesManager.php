<?php
namespace textboxs\forms;

use std, gui, framework, textboxs;


class FilesManager extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->IUser->image = new UXImage('./icons/user.png');
        $this->ILogout->image = new UXImage('./icons/logout.png');
        $this->getKey->callAsync();
    }

    /**
     * @event ILogout.click-Left 
     */
    function doILogoutClickLeft(UXMouseEvent $e = null)
    {    
        $this->logoutUI->call();
    }

    /**
     * @event LKey.click-Left 
     */
    function doLKeyClickLeft(UXMouseEvent $e = null)
    {    
        $this->toast('Ключ скопирован в буфер обмена');
        UXClipboard::setText(str::sub($this->LKey->text, 6));
    }

}
