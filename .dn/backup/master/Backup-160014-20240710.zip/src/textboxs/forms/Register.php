<?php
namespace textboxs\forms;

use std, gui, framework, textboxs;


class Register extends AbstractForm
{

    /**
     * @event BBack.action 
     */
    function doBBackAction(UXEvent $e = null)
    {    
        $this->loadForm('Login');
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->ILogo->image = new UXImage('./pic/cloud.png');
    }

}
