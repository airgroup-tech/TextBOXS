<?php
namespace textboxs\forms;

use std, gui, framework, textboxs;


class Login extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->ILogo->image = new UXImage('./pic/cloud.png');
    }

    /**
     * @event BReg.action 
     */
    function doBRegAction(UXEvent $e = null)
    {    
        $this->loadForm('Register');
    }

}
