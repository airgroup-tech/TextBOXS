<?php
namespace textboxs\forms;

use std, gui, framework, textboxs;


class Login extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->ILogo->image = new UXImage('./pic/cloud.png');
        
        if (file_exists('./config/save.aft') == true){
            $this->CSave->selected = true;
            $this->ELogin->text = urldecode(base64_decode(MainModule::getData('./config/save.aft', 'user', 'login')));
            $this->EPassword->text = urldecode(base64_decode(MainModule::getData('./config/save.aft', 'user', 'password')));
        }
    }

    /**
     * @event BReg.action 
     */
    function doBRegAction(UXEvent $e = null)
    {    
        $this->loadForm('Register');
    }

    /**
     * @event BLogin.action 
     */
    function doBLoginAction(UXEvent $e = null)
    {    
        if ($this->CSave->selected == true){
            if (file_exists('./config/save.aft') == false) file_put_contents('./config/save.aft', '');
            MainModule::setData('./config/save.aft', 'user', 'login', base64_encode(urlencode($this->ELogin->text)));
            MainModule::setData('./config/save.aft', 'user', 'password', base64_encode(urlencode($this->EPassword->text)));
        }else{
            unlink('./config/save.aft');
        }
        
        $this->showPreloader('Пожалуйста, подождите');
    }

}
