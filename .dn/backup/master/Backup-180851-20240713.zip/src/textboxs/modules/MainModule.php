<?php
namespace textboxs\modules;

use bundle\updater\UpdateMe;
use php\io\IOException;
use std, gui, framework, textboxs;
use php\Stream;


class MainModule extends AbstractModule
{
    
    public static function getData($file, $section, $key){
        
        $data = file_get_contents($file);
        
        $sections = str::split($data, ';');
        $sectionN = 0;
        
        for ($i = 0; $i < count($sections); $i++){
            $dataInSection = str::split($sections[$i], ':');
            if ($dataInSection[0] == $section) {
                $sectionN = $i;
                break;
            }
        }
        
        $sectionD = str::split($sections[$sectionN], ':')[1];
        $keys = str::split($sectionD, '%');
        $keyN = 0;
        
        for ($i = 0; $i < count($keys); $i++){
            $dataInKey = str::split($keys[$i], '?');
            if ($dataInKey[0] == $key){
                $keyN = $i;
                break;
            }
        }
        
        $temp = str::split($keys[$keyN], '?')[1];
        $temp = str::replace($temp, '\sim1', ';');
        $temp = str::replace($temp, '\sim2', ':');
        $temp = str::replace($temp, '\sim3', '%');
        $temp = str::replace($temp, '\sim4', '?');
        
        return $temp;
    }
    
    public static function setData($file, $section, $key, $dataKey){
        if (!file_exists($file)) file_put_contents($file, '');
        
        $dataKey = str::replace($dataKey, ';', '\sim1');
        $dataKey = str::replace($dataKey, ':', '\sim2');
        $dataKey = str::replace($dataKey, '%', '\sim3');
        $dataKey = str::replace($dataKey, '?', '\sim4');
        
        $data = file_get_contents($file);
        
        //Task "Check sections"
        
        $sections = str::split($data, ';');
        $sectionN = 0;
        $yesSection = false;
        
        for ($i = 0; $i < count($sections); $i++){
            $dataInSection = str::split($sections[$i], ':');
            if ($dataInSection[0] == $section){
                $yesSection = true;
                $sectionN = $i;
                break;
            }
        }
        
        if ($yesSection){
            //Task "Before and after data"
            $peredData = '';
            $posleData = '';
            $data = str::split($sections[$sectionN], ':')[1];
            for ($i = $sectionN + 1; $i < count($sections); $i++){
                $posleData .= ';' . $sections[$i];
            }
            for ($i = 0; $i < $sectionN; $i++){
                $peredData .= $sections[$i] . ';';
            }
            $peredData .= str::split($sections[$sectionN], ':')[0] . ':';
            
            //Task "Check key"
            $keys = str::split($data, '%');
            $keysN = 0;
            $yesKey = false;
            for ($i = 0; $i < count($keys); $i++){
                $dataInKey = str::split($keys[$i], '?');
                if ($dataInKey[0] == $key){
                    $keysN = $i;
                    $yesKey = true;
                    break;
                }
            }
            if ($yesKey){
                //Task "Before and after keys in data"
                $beforeKeys = '';
                $afterKeys = '';
                for ($i = $keysN + 1; $i < count($keys); $i++){
                    $afterKeys .= '%' . $keys[$i];
                }
                for ($i = 0; $i < $keysN; $i++){
                    $beforeKeys .= $keys[$i] . '%';
                }
                $beforeKeys .= str::split($keys[$keysN], '?')[0] . '?';
                
                //Task "Set to key"
                $data = $beforeKeys . $dataKey . $afterKeys;
            }else{
                //Task "Add to key"
                $data .= '%' . $key . '?' . $dataKey;
            }
            
            $newData = $peredData . $data . $posleData;
            
            file_put_contents($file, $newData);
        }else{
            //Task "Add to section and key"
            $newData = $data;
            if ($data != '') $newData .= ';';
            $newData .= $section;
            $newData .= ':';
            $newData .= $key;
            $newData .= '?';
            $newData .= $dataKey;
            
            file_put_contents($file, $newData);
        }
    }
    
    public static function dumpError($error, $function = "none"){
        global $lastUrl;
        
        $now = Time::now();
        $time = $now->toString('yyMM-dd HHmm ss');
        mkdir('dumps');
        $fileName = 'dumps/' . $time . '.dmp';
        $text = 'Dump error' . "\n" . 'System data: ' . $now->toString('dd.MM.yyyy HH:mm') . "\n" . 'Function: ' . $function . "\n" . 'Last URL: ' . $lastUrl . "\n" . 'Error: ' . "\n" . $error;
        Logger::error($text);
        Stream::putContents($fileName, $text);
    }
    
    public static function getStream($file, $arg){
        global $url, $lastUrl;
        
        $lastUrl = $url . $file . '?' . $arg;
        
        try {
            $stream = Stream::getContents($url . $file . '?' . $arg);
        } catch (IOException $ex){
            if (MainModule::getData('./config/config.aft', 'System', 'dumpError') == 'true'){
                MainModule::dumpError($ex, "MainModule::getStream");
            }else{
                Logger::error('Error: ' . $ex);
            }
            if (MainModule::getData('./config/config.aft', 'System', 'displayError') == 'true'){
                uiLaterAndWait(function () use ($ex){
                    if (MainModule::getData('./config/config.aft', 'System', 'advancedError') == 'true'){
                        UXDialog::showAndWait('Произошла ошибка!' . "\n" . 'Подробности: ' . $ex, 'ERROR');
                    }else{
                        UXDialog::showAndWait('Произошла ошибка!', 'ERROR');
                    }
                });
            }
        }
        
        return $stream;
    }
    
    /**
     * @event start.action 
     */
    function doStartAction(ScriptEvent $e = null)
    {    
        uiLaterAndWait(function (){
            $this->LInfo->text = 'Соединение с сервером';
        });
    
        global $url;
        
        Logger::info('Launching application');
    
        $ver = MainModule::getData('./config/config.aft', 'System', 'ver');
        $url = MainModule::getData('./config/config.aft', 'System', 'url');
        
        if (MainModule::getStream('check.php', '') != 'ok'){
            uiLaterAndWait(function (){
                $this->LInfo->text = 'Нет соединения с сервером';
            });
            return;
        }
        
        $server = MainModule::getStream('run.php', '');
        if ($server == 'pause'){
            uiLaterAndWait(function (){
                $this->LInfo->text = 'Сервер на тех. работах';
            });
            Logger::info('Server is tech');
            return;
        }else if ($server == 'stop'){
            Logger::error('Server closed');
            uiLaterAndWait(function (){
                $this->LInfo->text = 'Сервер остановлен';
                $this->LClose->show();
                UXDialog::showAndWait('Сервер закрыт!' . "\n" . 'Обратитесь к сайту программы, на данный момент обновления в программе не доступный!', 'ERROR');
            });
            return;
        }
        
        uiLaterAndWait(function (){
            $this->LInfo->text = 'Проверка обновлений';
        });
        
        UpdateMe::start($ver, 'updater.jar', function (){
            uiLaterAndWait(function (){
                $this->loadForm('Login');
            });
        });
    }

    /**
     * @event register.action 
     */
    function doRegisterAction(ScriptEvent $e = null)
    {    
        global $login, $password;
        
        uiLaterAndWait(function (){
            global $login, $password;
            $login = $this->ELogin->text;
            $password = $this->EPassword->text;
        });
        
        $return = MainModule::getStream('reg.php', 'login=' . urlencode($login) . '&password=' . urlencode($password));
        
        if ($return == 'ok'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Регистрация завершина!', 'INFORMATION');
            });
        }else if ($return == 'yes user'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Пользователь уже существует!', 'ERROR');
            });
        }else{
            MainModule::dumpError($return, "MainModule::register");
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Произошла не известная ошибка!', 'ERROR');
            });
        }
        
        uiLaterAndWait(function (){
            $this->hidePreloader();
        });
    }

    /**
     * @event login.action 
     */
    function doLoginAction(ScriptEvent $e = null)
    {    
        global $login, $password;
        
        uiLaterAndWait(function (){
            global $login, $password;
            $login = $this->ELogin->text;
            $password = $this->EPassword->text;
        });
        
        $return = MainModule::getStream('auth.php', 'login=' . urlencode($login) . '&password=' . urlencode($password));
        
        if ($return == 'ok'){
            uiLaterAndWait(function (){
                $this->loadForm('FilesManager');
            });
        }else if ($return == 'no user'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Пользователя не существует!', 'ERROR');
            });
        }else if ($return == 'incorect password'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Не верный пароль!', 'ERROR');
            });
        }else{
            MainModule::dumpError($return, "MainModule::login");
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Произошла не известная ошибка!', 'ERROR');
            });
        }
        
        uiLaterAndWait(function (){
            $this->hidePreloader();
        });
    }

    /**
     * @event checkData.action 
     */
    function doCheckDataAction(ScriptEvent $e = null)
    {    
        global $login, $key;
        
        uiLaterAndWait(function (){
            global $login, $key;
            $login = $this->ELogin->text;
            $key = $this->EKey->text;
        });
        
        $return = MainModule::getStream('resetPass1.php', 'login=' . urlencode($login) . '&key=' . urlencode($key));
        if ($return == 'ok'){
            uiLaterAndWait(function (){
                $this->ELogin->enabled = false;
                $this->EKey->enabled = false;
                $this->BCheck->enabled = false;
                $this->EPassword->enabled = true;
                $this->BComplect->enabled = true;
            });
        }else if ($return == 'no user'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Пользователя не существует!', 'ERROR');
            });
        }else if ($return == 'incorect key'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Ключ от пользователя не верный!', 'ERROR');
            });
        }else{
            MainModule::dumpError($return, "MainModule::checkData");
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Произошла не известная ошибка!', 'ERROR');
            });
        }
        
        uiLaterAndWait(function (){
            $this->hidePreloader();
        });
    }

    /**
     * @event setPass.action 
     */
    function doSetPassAction(ScriptEvent $e = null)
    {    
        global $login, $password;
        
        uiLaterAndWait(function (){
            global $login, $password;
            $login = $this->ELogin->text;
            $password = $this->EPassword->text;
        });
        
        $return = MainModule::getStream('resetPass2.php', 'login=' . $login . '&password=' . $password);
        if ($return == 'ok'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Пароль успешно сброшен!', 'INFORMATION');
                $this->loadForm('login');
            });
        }else if ($return == 'no user'){
            MainModule::dumpError($return, "MainModule::setPass");
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Произошла ошибка' . "\n" . 'Нам не удалось получить данные для востановления пароля, проверте данные логина и ключа' . "\n" . 'Возможно проблема связана с сервером', 'ERROR');
                $this->BCheck->enabled = true;
                $this->ELogin->enabled = true;
                $this->EKey->enabled = true;
                $this->EPassword->enabled = false;
                $this->BComplect->enabled = false;
            });
        }else{
            MainModule::dumpError($return, "MainModule::setPass");
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Произошла не известная ошибка!', 'ERROR');
            });
        }
        
        uiLaterAndWait(function (){
            $this->hidePreloader();
        });
    }

}
