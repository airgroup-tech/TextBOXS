<?php
namespace textboxs\forms;

use std, gui, framework, textboxs;


class Logout extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->IQuest->image = new UXImage('./icons/quest.png');
    }

    /**
     * @event BNo.action 
     */
    function doBNoAction(UXEvent $e = null)
    {    
        $this->loadForm('FilesManager');
    }

    /**
     * @event BLogout.action 
     */
    function doBLogoutAction(UXEvent $e = null)
    {    
        $this->loadForm('Login');
    }

}
