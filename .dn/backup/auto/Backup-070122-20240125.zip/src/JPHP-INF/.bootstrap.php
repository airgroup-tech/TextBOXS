<?php

// Generated.

use php\gui\framework\Application;



$app = new Application();

$app->loadModules(array (
  0 => 'textboxs\modules\AppModule',
));
$app->addStyle('/.theme/style.fx.css');
$app->launch();

