<?php
namespace textboxs\forms;

use std, gui, framework, textboxs;


class Font extends AbstractForm
{

    /**
     * @event BCancel.action 
     */
    function doBCancelAction(UXEvent $e = null)
    {    
        $this->hide();
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->CFont->items->clear();
        $this->CFont->items->addAll(UXFont::getFamilies());
        $this->CFont->selectedIndex = 0;
        
        $font = $this->CFont->selected;
        $size = intval($this->SSize->value);
        $style = $this->RStyle->selectedIndex;
                
        switch ($style){
            case 0:
                $fontX = UXFont::of($font, $size, 'THIN', false);
                break;
            case 1:
                $fontX = UXFont::of($font, $size, 'BOLD', false);
                break;
            case 2:
                $fontX = UXFont::of($font, $size, 'THIN', true);
                break;
            case 3:
                $fontX = UXFont::of($font, $size, 'BOLD', true);
                break;
        }
        
        $this->LHelp->font = $fontX;
    }

    /**
     * @event CFont.action 
     */
    function doCFontAction(UXEvent $e = null)
    {    
        $font = $this->CFont->selected;
        $size = intval($this->SSize->value);
        $style = $this->RStyle->selectedIndex;
                
        switch ($style){
            case 0:
                $fontX = UXFont::of($font, $size, 'THIN', false);
                break;
            case 1:
                $fontX = UXFont::of($font, $size, 'BOLD', false);
                break;
            case 2:
                $fontX = UXFont::of($font, $size, 'THIN', true);
                break;
            case 3:
                $fontX = UXFont::of($font, $size, 'BOLD', true);
                break;
        }
        
        $this->LHelp->font = $fontX;
    }

    /**
     * @event RStyle.action 
     */
    function doRStyleAction(UXEvent $e = null)
    {    
        $font = $this->CFont->selected;
        $size = intval($this->SSize->value);
        $style = $this->RStyle->selectedIndex;
                
        switch ($style){
            case 0:
                $fontX = UXFont::of($font, $size, 'THIN', false);
                break;
            case 1:
                $fontX = UXFont::of($font, $size, 'BOLD', false);
                break;
            case 2:
                $fontX = UXFont::of($font, $size, 'THIN', true);
                break;
            case 3:
                $fontX = UXFont::of($font, $size, 'BOLD', true);
                break;
        }
        
        $this->LHelp->font = $fontX;
    }

    /**
     * @event SSize.mouseMove 
     */
    function doSSizeMouseMove(UXMouseEvent $e = null)
    {    
        $font = $this->CFont->selected;
        $size = intval($this->SSize->value);
        $style = $this->RStyle->selectedIndex;
                
        switch ($style){
            case 0:
                $fontX = UXFont::of($font, $size, 'THIN', false);
                break;
            case 1:
                $fontX = UXFont::of($font, $size, 'BOLD', false);
                break;
            case 2:
                $fontX = UXFont::of($font, $size, 'THIN', true);
                break;
            case 3:
                $fontX = UXFont::of($font, $size, 'BOLD', true);
                break;
        }
        
        $this->LHelp->font = $fontX;
    }

    /**
     * @event SSize.mouseUp-Left 
     */
    function doSSizeMouseUpLeft(UXMouseEvent $e = null)
    {    
        $font = $this->CFont->selected;
        $size = intval($this->SSize->value);
        $style = $this->RStyle->selectedIndex;
                
        switch ($style){
            case 0:
                $fontX = UXFont::of($font, $size, 'THIN', false);
                break;
            case 1:
                $fontX = UXFont::of($font, $size, 'BOLD', false);
                break;
            case 2:
                $fontX = UXFont::of($font, $size, 'THIN', true);
                break;
            case 3:
                $fontX = UXFont::of($font, $size, 'BOLD', true);
                break;
        }
        
        $this->LHelp->font = $fontX;
    }

    /**
     * @event BDone.action 
     */
    function doBDoneAction(UXEvent $e = null)
    {    
        $font = $this->CFont->selected;
        $size = intval($this->SSize->value);
        $style = $this->RStyle->selectedIndex;
                
        switch ($style){
            case 0:
                $fontX = UXFont::of($font, $size, 'THIN', false);
                break;
            case 1:
                $fontX = UXFont::of($font, $size, 'BOLD', false);
                break;
            case 2:
                $fontX = UXFont::of($font, $size, 'THIN', true);
                break;
            case 3:
                $fontX = UXFont::of($font, $size, 'BOLD', true);
                break;
        }
        
        $this->form('FileEditor')->MText->font = $fontX;
        $this->hide();
    }

}
