<?php
namespace textboxs\forms;

use std, gui, framework, textboxs;


class Create extends AbstractForm
{

    /**
     * @event BCanel.action 
     */
    function doBCanelAction(UXEvent $e = null)
    {    
        $this->hide();
    }

}
