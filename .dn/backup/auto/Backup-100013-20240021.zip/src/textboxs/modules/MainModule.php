<?php
namespace textboxs\modules;

use bundle\updater\UpdateMe;
use php\io\IOException;
use std, gui, framework, textboxs;
use php\Stream;


class MainModule extends AbstractModule
{
    
    public static function getData($file, $section, $key){
        
        $data = file_get_contents($file);
        
        if (base64_encode(base64_decode($data)) === $data){
            $data = base64_decode($data);
        }
        
        $sections = str::split($data, ';');
        $sectionN = 0;
        
        for ($i = 0; $i < count($sections); $i++){
            $dataInSection = str::split($sections[$i], ':');
            if ($dataInSection[0] == $section) {
                $sectionN = $i;
                break;
            }
        }
        
        $sectionD = str::split($sections[$sectionN], ':')[1];
        $keys = str::split($sectionD, '%');
        $keyN = 0;
        
        for ($i = 0; $i < count($keys); $i++){
            $dataInKey = str::split($keys[$i], '?');
            if ($dataInKey[0] == $key){
                $keyN = $i;
                break;
            }
        }
        
        $temp = str::split($keys[$keyN], '?')[1];
        $temp = str::replace($temp, '\sim1', ';');
        $temp = str::replace($temp, '\sim2', ':');
        $temp = str::replace($temp, '\sim3', '%');
        $temp = str::replace($temp, '\sim4', '?');
        
        return $temp;
    }
    
    public static function setData($file, $section, $key, $dataKey){
        if (!file_exists($file)) file_put_contents($file, '');
        
        $dataKey = str::replace($dataKey, ';', '\sim1');
        $dataKey = str::replace($dataKey, ':', '\sim2');
        $dataKey = str::replace($dataKey, '%', '\sim3');
        $dataKey = str::replace($dataKey, '?', '\sim4');
        
        $data = file_get_contents($file);
        
        if (base64_encode(base64_decode($data)) === $data){
            $data = base64_decode($data);
        }
        
        //Task "Check sections"
        
        $sections = str::split($data, ';');
        $sectionN = 0;
        $yesSection = false;
        
        for ($i = 0; $i < count($sections); $i++){
            $dataInSection = str::split($sections[$i], ':');
            if ($dataInSection[0] == $section){
                $yesSection = true;
                $sectionN = $i;
                break;
            }
        }
        
        if ($yesSection){
            //Task "Before and after data"
            $peredData = '';
            $posleData = '';
            $data = str::split($sections[$sectionN], ':')[1];
            for ($i = $sectionN + 1; $i < count($sections); $i++){
                $posleData .= ';' . $sections[$i];
            }
            for ($i = 0; $i < $sectionN; $i++){
                $peredData .= $sections[$i] . ';';
            }
            $peredData .= str::split($sections[$sectionN], ':')[0] . ':';
            
            //Task "Check key"
            $keys = str::split($data, '%');
            $keysN = 0;
            $yesKey = false;
            for ($i = 0; $i < count($keys); $i++){
                $dataInKey = str::split($keys[$i], '?');
                if ($dataInKey[0] == $key){
                    $keysN = $i;
                    $yesKey = true;
                    break;
                }
            }
            if ($yesKey){
                //Task "Before and after keys in data"
                $beforeKeys = '';
                $afterKeys = '';
                for ($i = $keysN + 1; $i < count($keys); $i++){
                    $afterKeys .= '%' . $keys[$i];
                }
                for ($i = 0; $i < $keysN; $i++){
                    $beforeKeys .= $keys[$i] . '%';
                }
                $beforeKeys .= str::split($keys[$keysN], '?')[0] . '?';
                
                //Task "Set to key"
                $data = $beforeKeys . $dataKey . $afterKeys;
            }else{
                //Task "Add to key"
                $data .= '%' . $key . '?' . $dataKey;
            }
            
            $newData = $peredData . $data . $posleData;
            
            file_put_contents($file, $newData);
        }else{
            //Task "Add to section and key"
            $newData = $data;
            if ($data != '') $newData .= ';';
            $newData .= $section;
            $newData .= ':';
            $newData .= $key;
            $newData .= '?';
            $newData .= $dataKey;
            
            file_put_contents($file, $newData);
        }
    }
    
    public static function dumpError($error, $function = "none"){
        global $lastUrl;
        
        $now = Time::now();
        $time = $now->toString('yyMM-dd HHmm ss');
        mkdir('dumps');
        $fileName = 'dumps/' . $time . '.dmp';
        $text = 'Dump error' . "\n" . 'System data: ' . $now->toString('dd.MM.yyyy HH:mm') . "\n" . 'Function: ' . $function . "\n" . 'Last URL: ' . $lastUrl . "\n" . 'Error: ' . "\n" . $error;
        Logger::error($text);
        Stream::putContents($fileName, $text);
    }
    
    public static function getStream($file, $arg){
        global $url, $lastUrl;
        
        $lastUrl = $url . $file . '?' . $arg;
        
        try {
            $stream = Stream::getContents($url . $file . '?' . $arg);
        } catch (IOException $ex){
            if (MainModule::getData('./config/config.aft', 'System', 'dumpError') == 'true'){
                MainModule::dumpError($ex, "MainModule::getStream");
            }else{
                Logger::error('Error: ' . $ex);
            }
            if (MainModule::getData('./config/config.aft', 'System', 'displayError') == 'true'){
                uiLaterAndWait(function () use ($ex){
                    if (MainModule::getData('./config/config.aft', 'System', 'advancedError') == 'true'){
                        UXDialog::showAndWait('Произошла ошибка!' . "\n" . 'Подробности: ' . $ex, 'ERROR');
                    }else{
                        UXDialog::showAndWait('Произошла ошибка!', 'ERROR');
                    }
                });
            }
        }
        
        return $stream;
    }
    
    /**
     * @event start.action 
     */
    function doStartAction(ScriptEvent $e = null)
    {    
        uiLaterAndWait(function (){
            $this->LInfo->text = 'Соединение с сервером';
        });
    
        global $url;
        
        Logger::info('Launching application');
    
        $ver = MainModule::getData('./config/config.aft', 'System', 'ver');
        $url = MainModule::getData('./config/config.aft', 'System', 'url');
        
        if (MainModule::getStream('check.php', '') != 'ok'){
            uiLaterAndWait(function (){
                $this->LInfo->text = 'Нет соединения с сервером';
            });
            return;
        }
        
        $server = MainModule::getStream('run.php', '');
        if ($server == 'pause'){
            uiLaterAndWait(function (){
                $this->LInfo->text = 'Сервер на тех. работах';
            });
            Logger::info('Server is tech');
            return;
        }else if ($server == 'stop'){
            Logger::error('Server closed');
            uiLaterAndWait(function (){
                $this->LInfo->text = 'Сервер остановлен';
                $this->LClose->show();
                UXDialog::showAndWait('Сервер закрыт!' . "\n" . 'Обратитесь к сайту программы, на данный момент обновления в программе не доступный!', 'ERROR');
            });
            return;
        }
        
        uiLaterAndWait(function (){
            $this->LInfo->text = 'Проверка обновлений';
        });
        
        UpdateMe::start($ver, 'updater.jar', function (){
            uiLaterAndWait(function (){
                $this->loadForm('Login');
            });
        });
    }

    /**
     * @event register.action 
     */
    function doRegisterAction(ScriptEvent $e = null)
    {    
        global $login, $password;
        
        uiLaterAndWait(function (){
            global $login, $password;
            $login = $this->ELogin->text;
            $password = $this->EPassword->text;
        });
        
        $return = MainModule::getStream('reg.php', 'login=' . urlencode($login) . '&password=' . urlencode($password));
        
        if ($return == 'ok'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Регистрация завершина!', 'INFORMATION');
            });
        }else if ($return == 'yes user'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Пользователь уже существует!', 'ERROR');
            });
        }else{
            MainModule::dumpError($return, "MainModule::register");
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Произошла не известная ошибка!', 'ERROR');
            });
        }
        
        uiLaterAndWait(function (){
            $this->hidePreloader();
        });
    }

    /**
     * @event login.action 
     */
    function doLoginAction(ScriptEvent $e = null)
    {    
        global $login, $password, $dir, $page, $logined;
        
        uiLaterAndWait(function (){
            global $login, $password;
            $login = $this->ELogin->text;
            $password = $this->EPassword->text;
        });
        
        $return = MainModule::getStream('auth.php', 'login=' . urlencode($login) . '&password=' . urlencode($password));
        
        if ($return == 'ok'){
            $dir = '/root';
            $page = 0;
            $logined = true;
            uiLaterAndWait(function (){
                $this->form('FilesManager')->PPage->selectedPage = 0;
                $this->loadForm('FilesManager');
            });
        }else if ($return == 'no user'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Пользователя не существует!', 'ERROR');
            });
        }else if ($return == 'incorect password'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Не верный пароль!', 'ERROR');
            });
        }else{
            MainModule::dumpError($return, "MainModule::login");
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Произошла не известная ошибка!', 'ERROR');
            });
        }
        
        uiLaterAndWait(function (){
            $this->hidePreloader();
        });
    }

    /**
     * @event checkData.action 
     */
    function doCheckDataAction(ScriptEvent $e = null)
    {    
        global $login, $key;
        
        uiLaterAndWait(function (){
            global $login, $key;
            $login = $this->ELogin->text;
            $key = $this->EKey->text;
        });
        
        $return = MainModule::getStream('resetPass1.php', 'login=' . urlencode($login) . '&key=' . urlencode($key));
        if ($return == 'ok'){
            uiLaterAndWait(function (){
                $this->ELogin->enabled = false;
                $this->EKey->enabled = false;
                $this->BCheck->enabled = false;
                $this->EPassword->enabled = true;
                $this->BComplect->enabled = true;
            });
        }else if ($return == 'no user'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Пользователя не существует!', 'ERROR');
            });
        }else if ($return == 'incorect key'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Ключ от пользователя не верный!', 'ERROR');
            });
        }else{
            MainModule::dumpError($return, "MainModule::checkData");
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Произошла не известная ошибка!', 'ERROR');
            });
        }
        
        uiLaterAndWait(function (){
            $this->hidePreloader();
        });
    }

    /**
     * @event setPass.action 
     */
    function doSetPassAction(ScriptEvent $e = null)
    {    
        global $login, $password;
        
        uiLaterAndWait(function (){
            global $login, $password;
            $login = $this->ELogin->text;
            $password = $this->EPassword->text;
        });
        
        $return = MainModule::getStream('resetPass2.php', 'login=' . urlencode($login) . '&password=' . urlencode($password));
        if ($return == 'ok'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Пароль успешно сброшен!', 'INFORMATION');
                $this->loadForm('login');
            });
        }else if ($return == 'no user'){
            MainModule::dumpError($return, "MainModule::setPass");
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Произошла ошибка' . "\n" . 'Нам не удалось получить данные для востановления пароля, проверте данные логина и ключа' . "\n" . 'Возможно проблема связана с сервером', 'ERROR');
                $this->BCheck->enabled = true;
                $this->ELogin->enabled = true;
                $this->EKey->enabled = true;
                $this->EPassword->enabled = false;
                $this->BComplect->enabled = false;
            });
        }else{
            MainModule::dumpError($return, "MainModule::setPass");
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Произошла не известная ошибка!', 'ERROR');
            });
        }
        
        uiLaterAndWait(function (){
            $this->hidePreloader();
        });
    }

    /**
     * @event getKey.action 
     */
    function doGetKeyAction(ScriptEvent $e = null)
    {    
        global $login, $password;
        
        $return = MainModule::getStream('getKey.php', 'login=' . urlencode($login) . '&password=' . urlencode($password));
        
        if ($return == 'no user' or $return == 'incorect password'){
            $this->reloginUI->callUiLater();
            MainModule::dumpError($return, "MainModule::getKey");
        }else{
            uiLaterAndWait(function () use ($login, $return){
                $this->form('FilesManager')->LKey->text = str::replace($this->form('FilesManager')->LKey->text, '(key)', $return);
                $this->form('FilesManager')->LName->text = str::replace($this->form('FilesManager')->LName->text, '(user)', $login);
            });
        }
    }

    /**
     * @event logoutUI.action 
     */
    function doLogoutUIAction(ScriptEvent $e = null)
    {    
        $this->loadForm('Logout');
    }

    /**
     * @event reloginUI.action 
     */
    function doReloginUIAction(ScriptEvent $e = null)
    {    
        $this->form('Create')->hide();
        $this->loadForm('ReLogin');
    }

    /**
     * @event updateFiles.action 
     */
    function doUpdateFilesAction(ScriptEvent $e = null)
    {    
        global $login, $url, $dir, $maxFiles, $page, $number1, $number2, $files, $logined;
        
        if (str::contains($dir, 'root') == false){
            uiLaterAndWait(function (){
                $this->form('FilesManager')->BCreate->enabled = false;
            });
        }else{
            uiLaterAndWait(function (){
                $this->form('FilesManager')->BCreate->enabled = true;
            });
        }
        
        $this->hideAllInfo->callUiLater();
        
        Logger::info('Start func');
        Logger::debug('Page old: ' . $page);
        
        $stream = MainModule::getStream('filesmanager/getNumFiles.php', 'login=' . urlencode($login) . '&dir=' . urlencode($dir));
        if ($stream == 'no user'){
            uiLaterAndWait(function (){
                $this->hidePreloader();
            });
            $this->reloginUI->callUiLater();
            MainModule::dumpError($stream, 'MainModule::updateFiles');
        }
        
        Logger::debug('Old: ' . $stream);
        Logger::debug('Old type: ' . gettype($stream));
        $maxFiles = intval(str::trim($stream));
        Logger::debug('New type: ' . gettype($maxFiles));
        Logger::debug('New: ' . $maxFiles);
        
        uiLaterAndWait(function (){
            global $maxFiles, $page, $logined;
            $this->form('FilesManager')->PPage->total = $maxFiles;
            usleep(250);
            if ($logined == true){
                $logined = false;
                $this->form('FilesManager')->PPage->selectedPage = 0;
            }else{
                $this->form('FilesManager')->PPage->selectedPage = $page;
            }
        });
        
        if ($maxFiles == 0){
            uiLaterAndWait(function (){
                $this->form('FilesManager')->LNonFile->show();
            });
        }else{
            uiLaterAndWait(function (){
                $this->form('FilesManager')->LNonFile->hide();
            });
        
            Logger::debug('Page old: ' . $page);
            Logger::debug('Old: ' . $maxFiles);
            Logger::debug('Type: ' . gettype($maxFiles));
            $maxFiles = intval(str::trim($maxFiles));
            Logger::debug('Int: ' . $maxFiles);
            $tmp = $maxFiles / 5;
            $maxPages = intval($tmp);
            if (is_float($tmp)) $maxPages++;
            Logger::debug('Файлов: ' . $maxFiles);
            if ($page == -1) $page = 0;
            Logger::debug('Page old: ' . $page);
            Logger::debug('Page: ' . $page);
            if ($page == 0){
                Logger::debug('Number 1.1: ' . $number1);
                $number1 = 1;
            }else{
                Logger::debug('Number 1.2: ' . $number1);
                $number1 = $page * 5 + 1;
            }
            if ($maxFiles < 5) {
                $number2 = $maxFiles;
                Logger::debug('1');
            }else if ($page == $maxPages) {
                $number2 = $maxFiles;
                Logger::debug('2');
            }else{
                $number2 = $number1 + 4;
            }
            Logger::debug('Ot: ' . $number1);
            Logger::debug('Do: ' . $number2);
        }
        
        $stream = MainModule::getStream('filesmanager/getFiles.php', 'login=' . urlencode($login) . '&dir=' . urlencode($dir));
        if ($stream == 'no user'){
            MainModule::dumpError($stream, 'MainModule::updateiles');
            uiLaterAndWait(function (){
                $this->hidePreloader();
            });
            $this->reloginUI->callUiLater();
        }
        
        $files = $stream;
        $files = str::split($files, ';');
        var_dump($files);
        
        if ($maxFiles > 0){
            Logger::debug('Поиск элементов');
            for ($i = 0; $i < count($files); $i++){
                $tmp = str::split($files[$i], ',');
                var_dump($tmp);
                $is1 = intval(str::trim($tmp[0]));
                $is1++;
                Logger::debug($is1);
                if ($is1 >= $number1 and $is1 <= $number2){
                    global $name2, $text, $name1;
                    Logger::debug('Number: ' . $tmp[0]);
                    Logger::debug('Name: ' . $tmp[2]);
                    Logger::debug('Type: ' . $tmp[1]);
                    $is2 = $is1 - $number1 + 1;
                    Logger::debug('is2: ' . $is2);
                    $name1 = 'IObject' . $is2;
                    $name2 = 'LObject' . $is2;
                    $text = $tmp[2];
                    Logger::debug('Name 1: ' . $name1);
                    Logger::debug('Name 2: ' . $name2);
                    uiLaterAndWait(function (){
                        global $name2, $text;
                        $this->form('FilesManager')->$name2->show();
                        $this->form('FilesManager')->$name2->text = $text;
                    });
                    if (str::trim($tmp[1]) == "file") {
                        Logger::debug('file');
                        uiLaterAndWait(function (){
                            global $name1;
                            $this->form('FilesManager')->$name1->show();
                            $this->form('FilesManager')->$name1->image = new UXImage('./icons/file.png'); 
                        });
                    }else if (str::trim($tmp[1]) == "dir") {
                        uiLaterAndWait(function (){
                            global $name1;
                            $this->form('FilesManager')->$name1->show();
                            $this->form('FilesManager')->$name1->image = new UXImage('./icons/folder.png'); 
                        });
                    }else if (str::trim($tmp[1]) == "chat") {
                        uiLaterAndWait(function (){
                            global $name1;
                            $this->form('FilesManager')->$name1->show();
                            $this->form('FilesManager')->$name1->image = new UXImage('./icons/chat.png'); 
                        });
                    }else if (str::trim($tmp[1]) == "disk"){
                        uiLaterAndWait(function (){
                            global $name1;
                            $this->form('FilesManager')->$name1->show();
                            $this->form('FilesManager')->$name1->image = new UXImage('./icons/disk.png'); 
                        });
                    }
                }
            }
        }
        uiLaterAndWait(function (){
            $this->hidePreloader();
        });
    }

    /**
     * @event hideAllInfo.action 
     */
    function doHideAllInfoAction(ScriptEvent $e = null)
    {    
        for ($i = 1; $i <= 5; $i++){
            $name1 = 'IObject' . $i;
            $name2 = 'RObject' . $i;
            $name3 = 'LObject' . $i;
            $this->form('FilesManager')->$name1->hide();
            $this->form('FilesManager')->$name2->hide();
            $this->form('FilesManager')->$name3->hide();
        }
        $this->form('FilesManager')->LNonFile->hide();
    }

    /**
     * @event hideAll.action 
     */
    function doHideAllAction(ScriptEvent $e = null)
    {    
        global $isClick;
        if ($isClick == true){
            $isClick = false;
            return;
        }
        for ($i = 1; $i <= 5; $i++){
            $name2 = 'RObject' . $i;
            $this->form('FilesManager')->$name2->hide();
        }
    }

    /**
     * @event open.action 
     */
    function doOpenAction(ScriptEvent $e = null)
    {    
        global $select, $number1, $files, $dir, $logined;
        
        $object = $number1 + $select - 1;
        $tmp = $files[$object - 1];
        Logger::debug('Object: ' . $object);
        $type = str::split($tmp, ',')[1];
        
        if ($type == 'dir'){
            if ($dir[str::length($dir) - 1] != '/') $dir .= '/';
            $dir .= str::split($tmp, ',')[2];
            $logined = true;
            $this->EUrl->text = $dir;
            $this->showPreloader('Пожалуйста, подождите');
            $this->updateFiles->callAsync();
        }else if ($type == 'disk'){
            if ($dir[str::length($dir) - 1] != '/') $dir .= '/';
            $dir .= str::split($tmp, ',')[2];
            $logined = true;
            $this->EUrl->text = $dir;
            $this->showPreloader('Пожалуйста, подождите');
            $this->updateFiles->callAsync();
        }else if ($type == 'file'){
            $this->showPreloader('Пожалуйста, подождите');
            $this->openFile->callAsync();
        }
    }

    /**
     * @event create.action 
     */
    function doCreateAction(ScriptEvent $e = null)
    {    
        global $dir, $login, $type, $name;
        
        $type = 0;
        $name = '';
        
        uiLaterAndWait(function (){
            global $type, $name;
            $type = $this->form('Create')->RType->selectedIndex;
            $name = $this->form('Create')->EName->text;
        });
        
        if ($type == 0) $type = 'file';
        else if ($type == 1) $type = 'dir';
        else if ($type == 2) $type = 'chat';
        
        Logger::debug('Тип: ' . $type);
        
        $return = MainModule::getStream('filesmanager/create.php', 'login=' . urlencode($login . '?') . '&dir=' . urlencode($dir) . '&type=' . urlencode($type) . '&name=' . urlencode($name));
        if ($return == 'no user'){
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Произошла ошибка!' . "\n" . 'Возможно при авторизации произошла ошибка, попробуйте еще раз войти в свой аккаунт', 'ERROR');
            });
            MainModule::dumpError($return, "MainModule::create");
        }else if ($return == 'ok'){
            $this->hideAll->callUiLater();
            $this->updateFiles->callAsync();
        }else{
            MainModule::dumpError($return, 'MainModule::create');
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Произошла не известная ошибка!', 'ERROR');
            });
        }
        
        uiLaterAndWait(function (){
            $this->hidePreloader();
            $this->form('Create')->hide();
        });
    }

    /**
     * @event openFile.action 
     */
    function doOpenFileAction(ScriptEvent $e = null)
    {    
        global $login, $dir, $select, $files, $number1;
        
        $object = $number1 + $select - 1;
        $tmp = $files[$object - 1];
        Logger::debug('Object: ' . $object);
        $name = str::split($tmp, ',')[2];
        
        $return = MainModule::getStream('filesmanager/downloadFile.php', 'login=' . urlencode($login) . '&dir=' . urlencode($dir) . '&name=' . urlencode($name));
        if ($return == 'no user'){
            MainModule::dumpError($return, 'MainModule::openFile');
            uiLaterAndWait(function (){
                UXDialog::showAndWait('Произошла ошибка!' . "\n" . 'Возможно во время авторизации произошла ошибка, попробуйте ещё раз войти в свой аккаунт', 'ERROR');
            });
        }else{
            mkdir('tmp');
            file_put_contents('tmp/data', base64_encode($return));
            
            $nameF = MainModule::getData('./tmp/data', 'Info', 'Name');
            if ($nameF != $name){
                MainModule::dumpError('Not is name', 'MainModule::openFile');
                uiLaterAndWait(function (){
                    UXDialog::showAndWait('Вам отказано в доступе!', 'ERROR');
                });
            }else{
                $font = MainModule::getData('./tmp/data', 'Info', 'Font');
                $size = intval(str::trim(MainModule::getData('./tmp/data', 'Info', 'Size')));
                $style = MainModule::getData('./tmp/data', 'Info', 'Style');
                
                switch ($style){
                    case 'R':
                        $fontX = UXFont::of($font, $size, 'THIN', false);
                        break;
                    case 'B':
                        $fontX = UXFont::of($font, $size, 'BOLD', false);
                        break;
                    case 'I':
                        $fontX = UXFont::of($font, $size, 'THIN', true);
                        break;
                    case 'BI':
                        $fontX = UXFont::of($font, $size, 'BOLD', true);
                        break;
                }
                
                $text = MainModule::getData('./tmp/data', 'Data', 'Text');
                
                uiLaterAndWait(function () use ($fontX, $text, $name){
                    $this->form('FileEditor')->MText->font = $fontX;
                    $this->form('FileEditor')->MText->text = $text;
                    $this->form('FileEditor')->LName->text = $name;
                });
                
                $this->fileEditorUI->callUiLater();
            }
        }
        
        uiLaterAndWait(function (){
            $this->form('FilesManager')->hidePreloader();
        });
    }

    /**
     * @event fileEditorUI.action 
     */
    function doFileEditorUIAction(ScriptEvent $e = null)
    {    
        $this->loadForm('FileEditor');
    }

    /**
     * @event saveFile.action 
     */
    function doSaveFileAction(ScriptEvent $e = null)
    {    
        global $login, $dir, $select, $files, $number1;
        
        $object = $number1 + $select - 1;
        $tmp = $files[$object - 1];
        Logger::debug('Object: ' . $object);
        $name = str::split($tmp, ',')[2];
        
        global $font, $bold, $italic, $size, $text;
        
        uiLaterAndWait(function (){
           global $font, $bold, $italic, $size, $text;
           $font = $this->MText->font->family;
           $bold = $this->MText->font->bold;
           $italic = $this->MText->font->italic;
           $size = $this->MText->font->size; 
           $text = $this->MText->text;
        });
        
        $style = '';
        
        if ($bold == true) $style = $style . 'B';
        if ($italic == true) $style = $style . 'I';
        if ($style == '') $style = 'R';
        
        MainModule::setData('./tmp/data', 'Info', 'Font', $font);
        MainModule::setData('./tmp/data', 'Info', 'Style', $style);
        MainModule::setData('./tmp/data', 'Info', 'Size', $size);
        MainModule::setData('./tmp/data', 'Data', 'Text', $text);
        
        $data = file_get_contents('./tmp/data');
        $data = base64_decode($data);
        $data = str_split($data, 10);
        
        Logger::debug('Start' . count($data));
        
        for ($i = 0; $i < count($data); $i++){
            Logger::debug('Wait ' . $i);
            
            if ($i == 1) $return = MainModule::getStream('filesmanager/setData.php', 'login=' . urlencode($login) . '&dir=' . urlencode($dir) . '&name=' . urlencode($name) . '&data=' . urlencode($data[$i]) . '&set=' . urlencode('true'));
            else $return = MainModule::getStream('filesmanager/setData.php', 'login=' . urlencode($login) . '&dir=' . urlencode($dir) . '&name=' . urlencode($name) . '&data=' . urlencode($data[$i]) . '&set=' . urlencode('false'));
            
            if ($return == 'no user'){
                Logger::debug('Error ' . $i);
                MainModule::dumpError($return, 'MainModule::saveFile');
                uiLaterAndWait(function (){
                    UXDialog::showAndWait('Произошла ошибка!' . "\n" . 'Возможно во время авторизации произошла ошибка, попробуйте еще раз войти в свой аккаунт', 'ERROR');
                });
                break;
            }else if ($return == 'ok'){
                Logger::debug('OK ' . $i);
            }else{
                Logger::debug('Error ' . $i);
                MainModule::dumpError($return, 'MainModule::saveFile');
                uiLaterAndWait(function (){
                    UXDialog::showAndWait('Произошла ошибка', 'ERROR');
                });
                break;
            }
        }
        
        uiLaterAndWait(function (){
            $this->hidePreloader();
        });
    }


}
