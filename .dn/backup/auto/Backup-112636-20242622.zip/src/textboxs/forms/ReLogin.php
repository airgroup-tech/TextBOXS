<?php
namespace textboxs\forms;

use std, gui, framework, textboxs;


class ReLogin extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->ILogo->image = new UXImage('./icons/key.png');
    }

    /**
     * @event BLogin.action 
     */
    function doBLoginAction(UXEvent $e = null)
    {   
        $this->showPreloader('Пожалуйста, подождите');
        $this->login->callAsync();
    }

}
