<?php
namespace textboxs\forms;

use std, gui, framework, textboxs;


class Create extends AbstractForm
{

    /**
     * @event BCanel.action 
     */
    function doBCanelAction(UXEvent $e = null)
    {    
        $this->hide();
    }

    /**
     * @event BCreate.action 
     */
    function doBCreateAction(UXEvent $e = null)
    {    
        $this->showPreloader('Пожалуйста, подождите');
        $this->create->callAsync();
    }

}
