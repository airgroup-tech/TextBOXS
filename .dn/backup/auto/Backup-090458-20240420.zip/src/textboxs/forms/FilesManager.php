<?php
namespace textboxs\forms;

use std, gui, framework, textboxs;


class FilesManager extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        global $dir;
        $this->IUser->image = new UXImage('./icons/user.png');
        $this->ILogout->image = new UXImage('./icons/logout.png');
        $this->PPage->selectedPage = 1;
        $this->EUrl->text = $dir;
        $this->getKey->callAsync();
        $this->hideAllInfo->call();
        $this->updateFiles->callAsync();
    }

    /**
     * @event ILogout.click-Left 
     */
    function doILogoutClickLeft(UXMouseEvent $e = null)
    {    
        $this->logoutUI->call();
    }

    /**
     * @event LKey.click-Left 
     */
    function doLKeyClickLeft(UXMouseEvent $e = null)
    {    
        $this->toast('Ключ скопирован в буфер обмена');
        UXClipboard::setText(str::sub($this->LKey->text, 6));
    }

    /**
     * @event EUrl.globalKeyDown-Enter 
     */
    function doEUrlGlobalKeyDownEnter(UXKeyEvent $e = null)
    {    
        global $dir, $page;
        $dir = $this->EUrl->text;
        $page = 0;
        $this->updateFiles->callAsync();
        $this->showPreloader('Пожалуйста, подождите');
    }

    /**
     * @event BUrl.action 
     */
    function doBUrlAction(UXEvent $e = null)
    {    
        global $dir, $page;
        $page = 1;
        $dir = $this->EUrl->text;
        $this->updateFiles->callAsync();
        $this->showPreloader('Пожалуйста, подождите');
    }

    /**
     * @event PPage.action 
     */
    function doPPageAction(UXEvent $e = null)
    {    
        global $page;
        $page = $this->PPage->selectedPage;
        $this->showPreloader('Пожалуйста, подождите');
        $this->updateFiles->callAsync();
    }

    /**
     * @event click-Left 
     */
    function doClickLeft(UXMouseEvent $e = null)
    {    
        $this->hideAll->call();
    }

    /**
     * @event IObject1.mouseDown-Left 
     */
    function doIObject1MouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->hideAll->call();
        global $isClick, $select;
        $isClick = true;
        $select = 1;
        $this->RObject1->show();
    }

    /**
     * @event LObject1.mouseDown-Left 
     */
    function doLObject1MouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->hideAll->call();
        global $isClick, $select;
        $isClick = true;
        $select = 1;
        $this->RObject1->show();
    }

    /**
     * @event LObject2.mouseDown-Left 
     */
    function doLObject2MouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->hideAll->call();
        global $isClick, $select;
        $isClick = true;
        $select = 2;
        $this->RObject2->show();
    }

    /**
     * @event IObject2.mouseDown-Left 
     */
    function doIObject2MouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->hideAll->call();
        global $isClick, $select;
        $isClick = true;
        $select = 2;
        $this->RObject2->show();
    }

    /**
     * @event IObject3.mouseDown-Left 
     */
    function doIObject3MouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->hideAll->call();
        global $isClick, $select;
        $isClick = true;
        $select = 3;
        $this->RObject3->show();
    }

    /**
     * @event LObject3.mouseDown-Left 
     */
    function doLObject3MouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->hideAll->call();
        global $isClick, $select;
        $isClick = true;
        $select = 3;
        $this->RObject3->show();
    }

    /**
     * @event LObject4.mouseDown-Left 
     */
    function doLObject4MouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->hideAll->call();
        global $isClick, $select;
        $isClick = true;
        $select = 4;
        $this->RObject4->show();
    }

    /**
     * @event IObject4.mouseDown-Left 
     */
    function doIObject4MouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->hideAll->call();
        global $isClick, $select;
        $isClick = true;
        $select = 4;
        $this->RObject4->show();
    }

    /**
     * @event IObject5.mouseDown-Left 
     */
    function doIObject5MouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->hideAll->call();
        global $isClick, $select;
        $isClick = true;
        $select = 5;
        $this->RObject5->show();
    }

    /**
     * @event LObject5.mouseDown-Left 
     */
    function doLObject5MouseDownLeft(UXMouseEvent $e = null)
    {    
        $this->hideAll->call();
        global $isClick, $select;
        $isClick = true;
        $select = 5;
        $this->RObject5->show();
    }

    /**
     * @event IObject1.click-2x 
     */
    function doIObject1Click2x(UXMouseEvent $e = null)
    {    
        $this->open->call();
    }

    /**
     * @event LObject1.click-2x 
     */
    function doLObject1Click2x(UXMouseEvent $e = null)
    {    
        $this->open->call();
    }

    /**
     * @event IObject2.click-2x 
     */
    function doIObject2Click2x(UXMouseEvent $e = null)
    {    
        $this->open->call();
    }

    /**
     * @event LObject2.click-2x 
     */
    function doLObject2Click2x(UXMouseEvent $e = null)
    {    
        $this->open->call();
    }

    /**
     * @event IObject3.click-2x 
     */
    function doIObject3Click2x(UXMouseEvent $e = null)
    {    
        $this->open->call();
    }

    /**
     * @event LObject3.click-2x 
     */
    function doLObject3Click2x(UXMouseEvent $e = null)
    {    
        $this->open->call();
    }

    /**
     * @event IObject4.click-2x 
     */
    function doIObject4Click2x(UXMouseEvent $e = null)
    {    
        $this->open->call();
    }

    /**
     * @event LObject4.click-2x 
     */
    function doLObject4Click2x(UXMouseEvent $e = null)
    {    
        $this->open->call();
    }

    /**
     * @event IObject5.click-2x 
     */
    function doIObject5Click2x(UXMouseEvent $e = null)
    {    
        $this->open->call();
    }

    /**
     * @event LObject5.click-2x 
     */
    function doLObject5Click2x(UXMouseEvent $e = null)
    {    
        $this->open->call();
    }

    /**
     * @event BCreate.action 
     */
    function doBCreateAction(UXEvent $e = null)
    {    
        app()->showFormAndWait('Create');
    }




}
