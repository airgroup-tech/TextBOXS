<?php
namespace textboxs\forms;

use std, gui, framework, textboxs;


class FileEditor extends AbstractForm
{

    /**
     * @event BBack.action 
     */
    function doBBackAction(UXEvent $e = null)
    {    
        $this->loadForm('FilesManager');
    }

    /**
     * @event BFont.action 
     */
    function doBFontAction(UXEvent $e = null)
    {    
        $this->form('Font')->showAndWait();
    }

}
