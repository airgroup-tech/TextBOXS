<?php
namespace textboxs\forms;

use std, gui, framework, textboxs;


class MainForm extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->LClose->hide();
        $this->ILogo->image = new UXImage('pic/logo non fone.png');
        $this->start->callAsync();
    }

    /**
     * @event LClose.click-Left 
     */
    function doLCloseClickLeft(UXMouseEvent $e = null)
    {    
        exit;
    }

}
