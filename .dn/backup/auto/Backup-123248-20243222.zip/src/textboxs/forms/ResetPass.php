<?php
namespace textboxs\forms;

use std, gui, framework, textboxs;


class ResetPass extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        $this->ILogo->image = new UXImage('./pic/cloud.png');
        $this->BCheck->enabled = true;
        $this->ELogin->enabled = true;
        $this->EKey->enabled = true;
        $this->EPassword->enabled = false;
        $this->BComplect->enabled = false;
        $this->ELogin->text = '';
        $this->EKey->text = '';
        $this->EPassword->text = '';
    }

    /**
     * @event BBack.action 
     */
    function doBBackAction(UXEvent $e = null)
    {
        $this->loadForm('Login');
    }

    /**
     * @event BCheck.action 
     */
    function doBCheckAction(UXEvent $e = null)
    {    
        $this->showPreloader('Пожалуйста, подождите');
        $this->checkData->callAsync();
    }

    /**
     * @event BComplect.action 
     */
    function doBComplectAction(UXEvent $e = null)
    {    
        $this->showPreloader('Пожалуйста, подождите');
        $this->setPass->callAsync();
    }

}
