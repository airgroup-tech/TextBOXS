<?php
namespace textboxs\modules;

use std, gui, framework, textboxs;


class AppModule extends AbstractModule
{

}